<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta author="Benoit Delobel"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Inception RP est un serveur GTA Rp sur GTA V, nous vous invitons à nous rejoindre afin de profiter d&#039;une expérience RP unique sur un serveur GTA V RP. Rejoignez l&#039;aventure dès maintenant."/>
        <link rel="canonical" href="https://inception-rp.eu/" />
        <meta property="og:locale" content="fr_FR" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="GTA RP - Inception RP - Serveurs GTA V RP sur PC" />
        <meta property="og:description" content="Inception RP est un serveur GTA Rp sur GTA V, nous vous invitons à nous rejoindre afin de profiter d&#039;une expérience RP unique sur un serveur GTA V RP. Rejoignez l&#039;aventure dès maintenant." />
        <meta property="og:url" content="https://inception-rp.eu/" />
        <meta property="og:site_name" content="Inception Rp" />
    <title>Inception Roleplay</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" defer></script>
    <link rel="stylesheet" href="css/style.css">
    <script type="text/javascript" src="js/main.js" defer></script>
    <script type="text/javascript" src="js/time.js" defer></script>
	<script async custom-element="amp-auto-ads"
        src="https://cdn.ampproject.org/v0/amp-auto-ads-0.1.js">
</script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119391005-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119391005-1');
</script>

</head>
<body>
 <?php require('../private/config.php'); require('../private/function.php');?>   
 
    <div class="container-fluid">
        <div class="icon">
                <a href="#" data-toggle="modal" data-target="#douane"><img src="images/policeman.png"><br/>Demande de Visa</a> 
        </div>
        <div class="icon icon2">
                <a href="http://rocade.inception-rp.eu" target="blank"><img src="images/traffic-light.png"><br/>Rocade Serveur</a>        
        </div>
        
        <div class="icon icon3">
                <a href="#" data-toggle="modal" data-target="#staff"><img src="images/networking.png"><br/>Staff</a>     
        </div>

        <div class="icon icon4">
                <a href="#" data-toggle="modal" data-target="#ville"><img src="images/ville.png"><br/>Histoire de la ville</a>     
        </div>

        <div class="icon icon5">
                <a href="#" data-toggle="modal" data-target="#service"><img src="images/service.png"><br/>Entreprise de l'ile</a>     
        </div>
        

        <div class="icon icon6">
                <a href="https://www.paypal.me/franconfun" target="_blank"><img src="images/don.png"><br/>Faire un don</a>     
        </div>
        <div class="pub">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
 style="display:block; text-align:center;"
 data-ad-layout="in-article"
 data-ad-format="fluid"
 data-ad-client="ca-pub-2790999907129690"
 data-ad-slot="7628135475"></ins>
<script>
 (adsbygoogle = window.adsbygoogle 
 []).push({});
</script>
        </div>
    </div>
  
    <div class="displayNav">
            <div class="grid-windows blue">
                <div class="icon_active">
                        <a href="#" data-toggle="modal" data-target="#douane"><img src="images/policeman.png"><br/>Demande de Visa</a>
                </div>
            </div>

            <div class="grid-windows green">
                    <div class="icon_active">
                            <a href="http://rocade.inception-rp.eu" target="blank"><img src="images/traffic-light.png"><br/>Rocade Serveur</a>
                        </div>
            </div>

            <div class="grid-windows green ">
                    <div class="icon_active">
                            <a href="#" data-toggle="modal" data-target="#staff"><img src="images/networking.png"><br/>staff</a>
                        </div>
            </div>

            <div class="grid-windows blue">
            <div class="icon_active">
                        <a href="#" data-toggle="modal" data-target="#ville"><img src="images/ville.png"><br/>Notre Histoire</a>
                </div>
            </div>

            <div class="grid-windows blue">
            <div class="icon_active">
                        <a href="#" data-toggle="modal" data-target="#service"><img src="images/service.png"><br/>Nos Services</a>
                </div>
            </div>

            <div class="grid-windows green">
            <div class="icon_active">
                        <a href="https://www.paypal.me/franconfun" target="_blank" ><img src="images/don.png"><br/>Faire un Don</a>
                </div> 
            </div>

            <div class="grid-windows green">
                   
            </div>

            <div class="grid-windows blue">
                    
            </div>

            <div class="grid-windows blue">
                   
            </div>

            <div class="grid-windows green">
                  
            </div>
            
            
    </div>
    
    <div class="nav">
      <div class="toggler"><img src="images/logo.png"></div>
      <a href="https://discordapp.com/invite/hTyZ7pG" target="_blank" class="discord"><img src="images/discord-icon.png" style="width:50px; height:50px;"/></a>
      <a href="https://www.youtube.com/channel/UCF3hjtbKPhXydKOPInZhj0w" target="_blank" class="discord"><img src="images/youtube.png" style="width:50px; height:50px;"/></a>
      <div class="time" id="time"></div>
    </div>
    <?php require_once('../template/modal.php'); require_once('../private/action.php');?>
</body>
</body>
</body>

</body>
</body>
</html>