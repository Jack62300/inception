<?php
session_start();


/*$url_btn = "../public/admin.php";
$host = "localhost";
$bdd = "Inception";
$user = "inception_wp";
$pass = "hGjp!904"; */

$url_btn = "../../inception/public/admin.php";
$host = "localhost";
$bdd = "inception";
$user = "root";
$pass = ""; 


$sql = new PDO('mysql:host='.$host.';dbname='.$bdd.';charset=utf8', $user,$pass);